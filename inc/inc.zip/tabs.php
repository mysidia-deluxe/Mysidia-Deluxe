<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js'></script>
<script src="../../js/tabs.js"></script>
<script>
    $(function() {   
        $("#profile").organicTabs();            
    });
</script>