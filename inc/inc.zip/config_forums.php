<?php
//Mysidia Adoptables Site Configuration File

//Forum Integration Info: MyBB
$mybbenabled = 0; // 0 = disabled, 1 = enabled
$mybbhost = 'localhost'; // Consult your host if you believe this field is not localhost
$mybbuser = '';
$mybbpass = '';
$mybbdbname = '';
$mybbpath = '';
$mybbprefix = 'mybb_'; // This is the default setting as you install MyBB forum, feel free changing it if you have a different prefix
$mybbremember = -1;  		
?>