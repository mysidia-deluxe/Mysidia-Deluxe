<?php
//Mysidia Adoptables Site Configuration File

define('DBHOST', 'localhost');             //DB Hostname
define('DBUSER', 'root');             //DB Username
define('DBPASS', 'chibidog');             //DB Password
define('DBNAME', 'mys_deluxe');             //Your database name
define('DOMAIN', '127.0.0.1');             //Your domain name (No http, www or . )
define('SCRIPTPATH', '/mys_deluxe');     //The folder you installed this script in
define('PREFIX', 'adopts_');
?>