<?php

class ShopException extends Exception{
    
}
    
?>