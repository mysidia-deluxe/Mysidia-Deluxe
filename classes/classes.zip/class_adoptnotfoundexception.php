<?php

class AdoptNotfoundException extends InvalidIDException{

}
?>