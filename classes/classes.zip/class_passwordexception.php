<?php

class PasswordException extends Exception{

}
    
?>