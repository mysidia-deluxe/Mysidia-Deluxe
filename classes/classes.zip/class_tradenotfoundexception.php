<?php

class TradeNotfoundException extends InvalidIDException{

}
?>