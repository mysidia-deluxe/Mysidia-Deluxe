<?php

class DaycareException extends Exception{
    
}
    
?>