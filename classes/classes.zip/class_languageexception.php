<?php

class LanguageException extends Exception{

}
    
?>