<?php

class LevelupException extends Exception{
    
}
    
?>