<?php

class LevelNotfoundException extends InvalidIDException{

}
?>