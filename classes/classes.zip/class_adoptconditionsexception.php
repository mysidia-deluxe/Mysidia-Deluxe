<?php

class AdoptConditionsException extends Exception{

}
?>