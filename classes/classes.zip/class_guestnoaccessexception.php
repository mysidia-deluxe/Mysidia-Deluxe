<?php

class GuestNoaccessException extends Exception{

}
?>