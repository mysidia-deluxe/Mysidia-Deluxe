<?php

class SearchException extends Exception{

}

?>