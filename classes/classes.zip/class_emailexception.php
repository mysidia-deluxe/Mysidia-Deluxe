<?php

class EmailException extends Exception{

}
    
?>