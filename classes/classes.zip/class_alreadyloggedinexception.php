<?php

class AlreadyLoggedinException extends Exception{

}

?>