<?php

interface Rendering{
    public function start();
	public function pause();
	public function end();
}
    
?>