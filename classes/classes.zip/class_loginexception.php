<?php

class LoginException extends InvalidActionException{
    
}
    
?>