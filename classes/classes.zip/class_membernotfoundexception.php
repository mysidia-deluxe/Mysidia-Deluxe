<?php

class MemberNotfoundException extends InvalidIDException{

}
?>