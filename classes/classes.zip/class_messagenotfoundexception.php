<?php

class MessageNotfoundException extends Exception{

}
    
?>