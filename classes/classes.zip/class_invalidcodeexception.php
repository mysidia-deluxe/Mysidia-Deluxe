<?php

class InvalidCodeException extends Exception{

}
    
?>