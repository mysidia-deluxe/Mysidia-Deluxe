<?php

class BlankFieldException extends Exception{

}

?>