<?php

interface Renderable{
    public function render();
}
    
?>