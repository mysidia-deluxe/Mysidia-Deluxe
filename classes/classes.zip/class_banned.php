<?php

class Banned extends Member{

  public function __construct($user){
      parent::__construct($user);
  }

}
?>