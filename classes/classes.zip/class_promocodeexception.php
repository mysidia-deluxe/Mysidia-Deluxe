<?php

class PromocodeException extends Exception{

}
    
?>