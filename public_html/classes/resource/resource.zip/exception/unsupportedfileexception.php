<?php

class UnsupportedFileException extends Exception{

}
    
?>