<?php

namespace Resource\Exception;
use Exception;

class UnsupportedOperationException extends Exception{

}
    
?>