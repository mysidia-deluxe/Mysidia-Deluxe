<?php

class UrlException extends Exception{

}
    
?>