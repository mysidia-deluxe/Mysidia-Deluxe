<?php

class GUIException extends Exception{

}
    
?>