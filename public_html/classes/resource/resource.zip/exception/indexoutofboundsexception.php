<?php

namespace Resource\Exception;
use Exception;

class IndexOutOfBoundsException extends Exception{

}
    
?>