<?php

namespace Resource\Exception;
use Exception;

class ClassNotFoundException extends Exception{

}
    
?>