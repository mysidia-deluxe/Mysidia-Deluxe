<?php

namespace Resource\Exception;
use Exception;

class EmptyStackException extends Exception{

}
    
?>